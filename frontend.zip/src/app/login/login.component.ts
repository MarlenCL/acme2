import { Component, OnInit, OnDestroy, Inject, ViewChild, ElementRef } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { DisplayMessage } from '../shared/models/display-message';
import { Subscription } from 'rxjs/Subscription';
import { UserService, AuthService } from '../service';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/SUbject';
import 'tracking/build/tracking';
import 'tracking/build/data/face';

declare var window: any;
declare var tracking: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {

  title = 'Login';
  form: FormGroup;

  @ViewChild("video")
  public video: ElementRef;

  @ViewChild("canvas")
  public canvas: ElementRef;

  public captures: Array<any>;

  /**
   * Boolean used in telling the UI
   * that the form has been submitted
   * and is awaiting a response
   */
  submitted = false;

  /**
   * Notification message from received
   * form request or router
   */
  notification: DisplayMessage;

  returnUrl: string;
  private ngUnsubscribe: Subject<void> = new Subject<void>();

  constructor(
    private userService: UserService,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder
  ) { this.captures = []; }

  ngOnInit() {
    this.route.params
      .takeUntil(this.ngUnsubscribe)
      .subscribe((params: DisplayMessage) => {
        this.notification = params;
      });
    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    this.form = this.formBuilder.group({
      username: ['', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(64)])],
      password: ['', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(32)])]
    });
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  goToUrl() {

    console.log(JSON.stringify(this.userService.currentUser.rol));
    if (JSON.stringify(this.userService.currentUser.rol).search('ROLE_ADMIN') !== -1) {
      this.router.navigate(['/admin']);
    } else {
      this.router.navigate(['/home']);
    }
  }

  onResetCredentials() {
    this.userService.resetCredentials()
      .takeUntil(this.ngUnsubscribe)
      .subscribe(res => {
        if (res.result === 'success') {
          alert('Password has been reset to 123 for all accounts');
        } else {
          alert('Server error');
        }
      });
  }


  onSubmit() {
    /**
     * Innocent until proven guilty
     */
    this.notification = undefined;
    this.submitted = true;
    this.form.value.image = this.capture();
    this.authService.login(this.form.value, )
      // show me the animation
      .delay(1000)
      .subscribe(data => {
        this.userService.getMyInfo().subscribe();
        this.goToUrl();
      },
        error => {
          this.submitted = false;
          this.notification = { msgType: 'error', msgBody: 'Incorrect username or password.' };
        });

  }


  public ngAfterViewInit() {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
        this.video.nativeElement.src = window.URL.createObjectURL(stream);
        this.video.nativeElement.play();
        this.tracking();
      });
    };
  }

  public capture(): string {
      var context = this.canvas.nativeElement.getContext("2d").drawImage(this.video.nativeElement, 0, 0, 640, 480);
      this.captures.push(this.canvas.nativeElement.toDataURL("image/png"));
      var base64 = this.canvas.nativeElement.toDataURL("image/png").split(",")[1];
      return base64;
    }

  public tracking() {
    var tracker = new tracking.ObjectTracker("face");
    var video = document.getElementById('profile-img');
    var rect = document.createElement('div');
    tracker.on('track', function (event) {
      if (event.data.length === 0) {
        setInterval(function () { rect.style.border = "1px solid purple"; }, 2000);
      } else {
        event.data.forEach(function (rect) {
          window.plot(rect.x, rect.y, rect.height, rect.width);
        });
      }
    });
    tracking.track('video', tracker);
    window.plot = function (x, y, w, h) {
      document.getElementById('container1').appendChild(rect);
      rect.classList.add('rect');
      rect.style.width = w + 'px';
      rect.style.height = h + 'px';
      rect.style.border = "1px solid purple";
      rect.style.zIndex = "1";
      rect.style.position = "absolute";
      rect.style.left = (video.offsetLeft + x) + 'px';
      rect.style.top = (video.offsetTop + y) + 'px';
    };
  }
}
