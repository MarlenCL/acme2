export interface DisplayMessage {
  msgType: string;
  msgBody: string;
}
