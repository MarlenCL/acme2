export class MockUserService {

  currentUser = {};

}
